# MID-NIGHT-HACKATHON
 A python script which reads name and id from an .xlsx file and writes them in a image
